const msql = require('mssql');

const config = {
  server: '110.170.18.150',
  port: 1433,
  database: 'JQuoteLive',
  user: 'tulip',
  password: 'testtulip',
}

console.info('Connecting without encrypt');
mssql.connect(config, beforeConnect: conn => {
  conn.once('connect', err => { err ? console.error(JSON.stringify(err, null ,2)) : console.log('mssql connected')})
  conn.once('end', err => { err ? console.error(JSON.stringify(err, null ,2)) : console.log('mssql disconnected')})
}})

msql.on('error', err => {
  console.error('Got error', JSON.stringify(err, null ,2));
})
